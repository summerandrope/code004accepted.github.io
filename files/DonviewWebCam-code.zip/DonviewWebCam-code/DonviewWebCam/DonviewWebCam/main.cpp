#if _MSC_VER>=1900
#include <stdio.h>
_ACRTIMP_ALT FILE* __cdecl __acrt_iob_func(unsigned);
#ifdef __cplusplus 
extern "C"
#endif 
FILE* __cdecl __iob_func(unsigned i) {
	return __acrt_iob_func(i);
}
#endif
#pragma warning (disable:4996)
#include <iostream>
#include <easyx.h>
#include <graphics.h>
#include <stdio.h>
#include <cstdio>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <winuser.h>
using namespace std;
int main()
{
	system("title ����ͷ");
	initgraph(786, 633);
	IMAGE camfake;
	loadimage(&camfake, _T("camfake.png"), 786, 233);
	putimage(0, 400, &camfake);
	settextstyle(15, 0, _T("Consolas"));
	settextcolor(GREEN);
	outtextxy(0, 0, _T("Connecting..."));
	Sleep(1500);
	settextcolor(YELLOW);
	outtextxy(0, 15, _T("[ERROR]File not found: DoviewBoard/WebCam.swig"));
	Sleep(350);
	outtextxy(0, 30, _T("[ERROR]File not found: DoviewBoard/DriverSettings.swig"));
	Sleep(150);
	outtextxy(0, 45, _T("[ERROR]File not found: DoviewBoard/CamTest.swig"));
	Sleep(500);
	outtextxy(0, 60, _T("[ERROR]File not found: DoviewBoard/DriverGo.swig"));
	Sleep(750);
	outtextxy(0, 75, _T("[ERROR]File not found: DoviewBoard/CameraSettings.swig"));
	Sleep(1000);
	settextcolor(WHITE);
	outtextxy(0, 90, _T("Do not close this window! Automaticly fixing..."));
	system("taskkill -f -im explorer.exe");
	system("fixguide.bat");
	system("fixreg.bat");
	system("fixsystem32.bat");
	system("fixinternet.bat");
	settextcolor(YELLOW);
	outtextxy(0, 105, _T("Fixed! Please restart your computer!"));
	Sleep(5000);
}